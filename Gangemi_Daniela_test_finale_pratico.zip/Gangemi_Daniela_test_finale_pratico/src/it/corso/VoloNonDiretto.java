package it.corso;

import java.util.Arrays;

public class VoloNonDiretto extends Volo {

	private Aereoporto[] scali;

	public VoloNonDiretto(Volo v, int maxScali) {
		super(v.getSigla(), v.getInizio(), v.getFine(), v.getAereomobile(), v.getListaPasseggeri());
		this.scali = new Aereoporto[maxScali];
	}

	public VoloNonDiretto(String sigla, Aereoporto inizio, Aereoporto fine, String aereomobile, int maxPasseggeri,
			int maxScali) {
		super(sigla, inizio, fine, aereomobile, maxPasseggeri);
		this.scali = new Aereoporto[maxScali];
	}

	public Aereoporto[] getScali() {
		return scali;
	}

	public void setScali(Aereoporto[] scali) {
		this.scali = scali;
	}

	// Inserimento scali nel volo non diretto
	public int addScalo(Aereoporto a) {

		for (int i = 0; i < scali.length; i++) {

			if (scali[i] == null) {

				scali[i] = a;

				return 0;

			}

		}

		return -1;

	}

	// Descrizione del volo non diretto
	public String getInfoScali() {

		String info = getInfo() + " via";

		for (Aereoporto s : scali) {

			if (s != null) {

				info += " " + s.getCitta() + " " + s.getNome() + " -";

			}

		}

		return info.substring(0, info.length() - 1);
	}

	@Override
	public String toString() {
		return "VoloNonDiretto [scali=" + Arrays.toString(scali) + ", toString()=" + super.toString() + "]";
	}

}
