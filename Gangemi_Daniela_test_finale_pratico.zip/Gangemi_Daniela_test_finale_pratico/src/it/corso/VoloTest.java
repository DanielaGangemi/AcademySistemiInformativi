package it.corso;

import java.util.Arrays;

public class VoloTest {

	public static void main(String[] args) {

		// --- PUNTO 1 ---
		// Creazione di una istanza di tipo Aereoporto
		Aereoporto aereoporto = new Aereoporto("Galilei", "Pisa", "PSA");

		// Creazione di due istanza di tipo Passeggero
		Passeggero passeggero1 = new Passeggero("Daniela", "italiana", "AZ124", "16F", "vegetariano");
		Passeggero passeggero2 = new Passeggero("Enrico", "italiana", "AZ124", "18A", "classico");

		// Per ottenere i valori delle variabili d'istanza singolarmente si possono
		// utilizzare i metodi getter. Per avere tutte le informazioni di un'istanza
		// in una volta si usa il metodo toString().

		System.out.println("--- ESERCIZIO 1 ---\nInfo istanze ");
		System.out.println("aereoporto: " + aereoporto.toString()); // stampa tutte le info dell'istanza
		System.out.println("Nome aereoporto: " + aereoporto.getNome()); // stampa il nome associato all'istanza
		System.out.println("passeggero1: " + passeggero1.toString());
		System.out.println("passeggero2: " + passeggero2.toString());

		// Modifica il posto assegnato al passeggero1
		passeggero1.setPostoAssegnato("17A");

		System.out.println("\npasseggero1 modificato: " + passeggero1.toString());

		// --- PUNTO 2 ---
		// Creazione di un volo Catania - Palermo
		Aereoporto aereoporto1 = new Aereoporto("Vincenzo Bellini", "Catania", "CTA");
		Aereoporto aereoporto2 = new Aereoporto("Falcone e Borsellino", "Palermo", "PMO");

		Volo voloCataniaPalermo = new Volo("1234", aereoporto1, aereoporto2, "Airbus300", 3);

		System.out.println("\n--- ESERCIZIO 2 ---\nDettagli volo");
		System.out.println("voloCataniaPalermo: " + voloCataniaPalermo.toString());

		// Aggiunta passeggeri
		voloCataniaPalermo.addPasseggero(passeggero1);
		voloCataniaPalermo.addPasseggero(passeggero2);

		System.out.println("\nPasseggero inserito. Dettagli volo: ");
		System.out.println("voloCataniaPalermo: " + voloCataniaPalermo.toString());

		// Descrizione volo
		System.out.println("\nDescrizione voloCataniaPalermo: " + voloCataniaPalermo.getInfo());

		// Lista dei passeggeri
		System.out.println("Lista passeggeri: " + Arrays.toString(voloCataniaPalermo.getNomePasseggeri()));

		// Lista dei posti dei passeggeri con pasto vegetariano
		System.out.println("Lista passeggeri con pasto vegetariano: "
				+ Arrays.toString(voloCataniaPalermo.getPersoneVegetariane()));

		// Creazione di un volo non diretto
		VoloNonDiretto voloCataniaPalermoInd = new VoloNonDiretto(voloCataniaPalermo, 2);

		Aereoporto aereoporto3 = new Aereoporto("Sant'Eufemia", "Lamezia", "SUF");
		Aereoporto aereoporto4 = new Aereoporto("Aereoporto dello Stretto", "Reggio Calabria", "REG");

		// Inserimento scalo
		voloCataniaPalermoInd.addScalo(aereoporto3);
		voloCataniaPalermoInd.addScalo(aereoporto4);

		// Mostra informazioni scalo
		System.out.println("\nInfo volo Catania-Palermo con scalo: ");
		System.out.println("voloCataniaPalermoInd: " + voloCataniaPalermoInd.toString());

		System.out.println("\nDescrizione voloCataniaPalermoInd: " + voloCataniaPalermoInd.getInfoScali());

		
	}

}
