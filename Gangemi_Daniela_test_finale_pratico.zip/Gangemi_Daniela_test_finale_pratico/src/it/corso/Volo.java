package it.corso;

import java.util.Arrays;

public class Volo {

	private String sigla;
	private Aereoporto inizio;
	private Aereoporto fine;
	private String aereomobile;
	private Passeggero[] listaPasseggeri;

	public Volo(String sigla, Aereoporto inizio, Aereoporto fine, String aereomobile, int maxPasseggeri) {
		super();
		this.sigla = sigla;
		this.inizio = inizio;
		this.fine = fine;
		this.aereomobile = aereomobile;
		this.listaPasseggeri = new Passeggero[maxPasseggeri];
	}

	// Questo costruttore � stato inserito per agevolare l'inizializzazione di un
	// oggetto di tipo VoloNonDiretto
	public Volo(String sigla, Aereoporto inizio, Aereoporto fine, String aereomobile, Passeggero[] listaPasseggeri) {
		super();
		this.sigla = sigla;
		this.inizio = inizio;
		this.fine = fine;
		this.aereomobile = aereomobile;
		this.listaPasseggeri = listaPasseggeri;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public Aereoporto getInizio() {
		return inizio;
	}

	public void setInizio(Aereoporto inizio) {
		this.inizio = inizio;
	}

	public Aereoporto getFine() {
		return fine;
	}

	public void setFine(Aereoporto fine) {
		this.fine = fine;
	}

	public String getAereomobile() {
		return aereomobile;
	}

	public void setAereomobile(String aereomobile) {
		this.aereomobile = aereomobile;
	}

	public Passeggero[] getListaPasseggeri() {
		return listaPasseggeri;
	}

	public void setListaPasseggeri(Passeggero[] listaPasseggeri) {
		this.listaPasseggeri = listaPasseggeri;
	}

	// Inserimento passeggeri al volo
	public int addPasseggero(Passeggero p) {

		for (int i = 0; i < listaPasseggeri.length; i++) {

			if (listaPasseggeri[i] == null) {

				listaPasseggeri[i] = p;

				return 0;

			}

		}

		return -1;

	}

	// Descrizione del volo
	public String getInfo() {

		return "volo " + sigla + " " + inizio.getCitta() + " " + inizio.getNome() + " - " + fine.getCitta() + " "
				+ fine.getNome();
	}

	// Elenco passeggeri del volo
	public String[] getNomePasseggeri() {

		String[] passeggeri = new String[listaPasseggeri.length];
		int count = 0;

		for (int i = 0; i < listaPasseggeri.length; i++) {

			if (listaPasseggeri[i] != null) {

				passeggeri[count] = listaPasseggeri[i].getNome();
				count++;

			}
		}

		return passeggeri;

	}

	// Elenco posti dei passeggeri del volo con pasto "vegetariano"
	public String[] getPersoneVegetariane() {

		String[] passeggeri = new String[listaPasseggeri.length];
		int count = 0;

		for (int i = 0; i < listaPasseggeri.length; i++) {

			if (listaPasseggeri[i] != null) {

				if (listaPasseggeri[i].getPastoRichiesto() == "vegetariano") {

					passeggeri[count] = listaPasseggeri[i].getPostoAssegnato();
					count++;

				}

			}
		}

		return passeggeri;

	}

	@Override
	public String toString() {
		return "Volo [sigla=" + sigla + ", inizio=" + inizio + ", fine=" + fine + ", aereomobile=" + aereomobile
				+ ", listaPasseggeri=" + Arrays.toString(listaPasseggeri) + "]";
	}

}
