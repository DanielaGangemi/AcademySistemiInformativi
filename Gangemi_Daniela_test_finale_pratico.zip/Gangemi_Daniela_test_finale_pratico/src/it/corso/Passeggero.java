package it.corso;

public class Passeggero {

	private String nome;
	private String nazionalita;
	private String siglaVolo;
	private String postoAssegnato;
	private String pastoRichiesto;

	public Passeggero() {
		super();
	}

	public Passeggero(String nome, String siglaVolo) {
		super();
		this.nome = nome;
		this.siglaVolo = siglaVolo;
	}

	public Passeggero(String nome, String siglaVolo, String postoAssegnato) {
		super();
		this.nome = nome;
		this.siglaVolo = siglaVolo;
		this.postoAssegnato = postoAssegnato;
	}

	public Passeggero(String nome, String siglaVolo, String postoAssegnato, String pastoRichiesto) {
		super();
		this.nome = nome;
		this.siglaVolo = siglaVolo;
		this.postoAssegnato = postoAssegnato;
		this.pastoRichiesto = pastoRichiesto;
	}

	public Passeggero(String nome, String nazionalita, String siglaVolo, String postoAssegnato, String pastoRichiesto) {
		super();
		this.nome = nome;
		this.nazionalita = nazionalita;
		this.siglaVolo = siglaVolo;
		this.postoAssegnato = postoAssegnato;
		this.pastoRichiesto = pastoRichiesto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNazionalita() {
		return nazionalita;
	}

	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}

	public String getSiglaVolo() {
		return siglaVolo;
	}

	public void setSiglaVolo(String siglaVolo) {
		this.siglaVolo = siglaVolo;
	}

	public String getPostoAssegnato() {
		return postoAssegnato;
	}

	public void setPostoAssegnato(String postoAssegnato) {
		this.postoAssegnato = postoAssegnato;
	}

	public String getPastoRichiesto() {
		return pastoRichiesto;
	}

	public void setPastoRichiesto(String pastoRichiesto) {
		this.pastoRichiesto = pastoRichiesto;
	}

	@Override
	public String toString() {
		return "Passeggero [nome=" + nome + ", nazionalita=" + nazionalita + ", siglaVolo=" + siglaVolo
				+ ", postoAssegnato=" + postoAssegnato + ", pastoRichiesto=" + pastoRichiesto + "]";
	}

}
