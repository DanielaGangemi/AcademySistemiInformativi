package it.corso;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * La classe StudentGrade gestisce le valuzationi assegnate agli studenti.
 * Possiede un solo attributo che mappa lo studente con la sua valutazione.
 * 
 * @author Daniela
 * @version 1.0
 * 
 */

public class StudentGrades {

	private Map<String, Integer> evaluations;

	/**
	 * Metodo che restituisce la mappa, inizializzandola qualora il suo valore fosse
	 * null.
	 * 
	 * @return un tipo di dato Map con chiave String e valore Integer che descrive
	 *         le valutazioni assegnate agli studenti.
	 * 
	 */
	private Map<String, Integer> getEvaluations() {

		if (evaluations == null) {

			evaluations = new HashMap<>();

		}

		return evaluations;

	}

	/**
	 * Metodo che inserisce una coppia studente valutazione nella mappa delle
	 * valutazioni.
	 * 
	 * @param studentName nome dello studente
	 * @param grade       valutazione dello studente
	 * 
	 * @return tipo di dato Integer che e' null se la coppia chiave-valore e' nuova,
	 *         pari alla valutazione se lo studente gia' esiste e -1 se la
	 *         valutazione non rispetta i criteri richiesit.
	 * 
	 */
	public Integer addGrade(String studentName, int grade) {

		// valutazione non valida
		if (grade < 18 || grade > 31) {

			return -1;

		}

		return getEvaluations().put(studentName, grade);

	}

	/**
	 * Metodo che restituisce il voto di uno specifico studente.
	 * 
	 * @param studentName nome dello studente
	 * 
	 * @return un tipo di dato intero che identifica il voto dello studente. Se lo
	 *         studente non e' presente nella mappa allora ritorna -1.
	 * 
	 */
	public int getGrade(String studentName) {

		if (getEvaluations().containsKey(studentName)) {

			return getEvaluations().get(studentName);

		}

		return -1;

	}

	/**
	 * Metodo che stampa il contenuto della mappa.
	 * 
	 * 
	 */

	public void printGrades() {

		getEvaluations().forEach((key, value) -> System.out
				.println("Allo studente " + key + " e' stata assegnata la valutazione " + value));

	}

}
