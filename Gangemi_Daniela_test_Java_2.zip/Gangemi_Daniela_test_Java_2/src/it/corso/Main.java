package it.corso;

public class Main {

	/**
	 * Metodo che stampa se l'inserimento e' andato o meno a buon fine.
	 * 
	 * @param resIns risultato inserimento
	 * 
	 */

	public static void checkInsert(Integer resIns) {

		if (resIns != null && resIns == -1) {

			System.out.println("Questa valutazione non e' valida. Inserimento fallito.");

		} else {

			System.out.println("Valutazione valida. Inserimento riuscito.");
		}

	}

	/**
	 * Metodo che stampa la valutazione dello studente.
	 * 
	 * @param name  nome dello studente
	 * @param grade valutazione dello studente
	 * 
	 */
	public static void printGrade(String name, int grade) {

		if (grade == -1) {

			System.out.println("Questo studente non esiste.");

		} else {

			System.out.println("La valutazione di " + name + "  e': " + grade);
		}

	}

	public static void main(String[] args) {

		// Istanziazione oggetto StudentGrades.
		StudentGrades sg = new StudentGrades();

		// Inserimento dati.
		checkInsert(sg.addGrade("Daniela", 25));
		checkInsert(sg.addGrade("Samuele", 28));
		checkInsert(sg.addGrade("Irene", 27));
		checkInsert(sg.addGrade("Daniela", 37));

		// Stampa dati.
		sg.printGrades();

		// Ricerca per chiave (= nome studente).
		int gradeStud1 = sg.getGrade("Daniela");
		int gradeStud2 = sg.getGrade("Alessandra");

		printGrade("Daniela", gradeStud1);
		printGrade("Alessandra", gradeStud2);

	}

}
