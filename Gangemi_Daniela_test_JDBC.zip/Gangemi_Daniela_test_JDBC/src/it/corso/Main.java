package it.corso;

import java.sql.SQLException;

public class Main {

	public static void main(String[] args) {

		try {

			// CREATE DATABASE
			DbManipulation.createDatabase("test_jdbc");

			// CREATE TABLES
			DbManipulation.createTableUser("test_jdbc");
			DbManipulation.createTableBook("test_jdbc");
			DbManipulation.createTablePrestito("test_jdbc");

			// per gli inserimenti bisognerebbe gestire quale utente e' gia' stato inserito
			// e quale no, per evitare che se, ad esempio, Mario Rossi e' stato inserito ma
			// Andrea Verdi no, l'esecuzione del programma non entri nel catch.
			// Questa condizione non e' stata gestita perche' non era richiesto.

			// USER INSERTS
			try {
				DbManipulation.insertUserBook("test_jdbc", "Utente", 1, "Mario", "Rossi");
				DbManipulation.insertUserBook("test_jdbc", "Utente", 2, "Andrea", "Verdi");
				DbManipulation.insertUserBook("test_jdbc", "Utente", 3, "Massimo", "Bianchi");
				DbManipulation.insertUserBook("test_jdbc", "Utente", 4, "Sara", "Vallieri");
				DbManipulation.insertUserBook("test_jdbc", "Utente", 5, "Marco", "Graviglia");
				DbManipulation.insertUserBook("test_jdbc", "Utente", 6, "Marzia", "Esposito");
			} catch (Exception e) {
				System.out.println("Utente gia' inserito\n");
			}

			// BOOK INSERTS
			try {

				DbManipulation.insertUserBook("test_jdbc", "Libro", 1, "La divina commedia - inferno",
						"Dante Alighieri");
				DbManipulation.insertUserBook("test_jdbc", "Libro", 2, "La divina commedia - purgatorio",
						"Dante Alighieri");
				DbManipulation.insertUserBook("test_jdbc", "Libro", 3, "La divina commedia - paradiso",
						"Dante Alighieri");
				DbManipulation.insertUserBook("test_jdbc", "Libro", 4, "Persuasione", "Jane Austen");
				DbManipulation.insertUserBook("test_jdbc", "Libro", 5, "I Watson", "Jane Austen");
				DbManipulation.insertUserBook("test_jdbc", "Libro", 6, "Lady Susan", "Jane Austen");

			} catch (Exception e) {
				System.out.println("Libro gia' inserito\n");
			}

			System.out.println("1) Tutti i libri prestati all'utente Valieri in ordine cronologico");
			DbManipulation.getBooksBySurname("test_jdbc", "Vallieri");

			System.out.println("\n2) I primi tre lettori che hanno letto pi� libri");
			DbManipulation.getBestReader("test_jdbc");

			System.out.println("\n3) Tutti i possessori dei libri non ancora rientrati e il titolo degli stessi");
			DbManipulation.getBookNotReturnet("test_jdbc");

			System.out.println("\n4) Storico dei libri chiesti in prestito da un utente indicando il periodo");
			DbManipulation.getHistory("test_jdbc", "Verdi", "2024-03-03", "2024-04-03");

			System.out.println("\n6) Prestiti la cui data supera i 15 giorni");
			DbManipulation.getBorrowedBooks("test_jdbc");

		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

}
