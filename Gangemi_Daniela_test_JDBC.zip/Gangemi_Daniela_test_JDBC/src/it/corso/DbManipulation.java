package it.corso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.jdbc.MysqlDataSource;

public class DbManipulation {

	private static Connection conn;

	public static Connection startConnection(String nomeDb) throws SQLException {

		if (conn == null) {

			MysqlDataSource dataSource = new MysqlDataSource();

			dataSource.setServerName("localhost");
			dataSource.setPortNumber(3306);
			dataSource.setUser("root");
			dataSource.setPassword("admin");
			dataSource.setDatabaseName(nomeDb);

			conn = dataSource.getConnection();

		}

		return conn;
	}

	public static void createDatabase(String nome) throws SQLException {

		String sql = "CREATE DATABASE IF NOT EXISTS " + nome;

		PreparedStatement ps = startConnection(null).prepareStatement(sql);

		ps.executeUpdate();

	}

	private static void useDatabase(String dbName) throws SQLException {

		String sql = "USE " + dbName;

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.executeUpdate();

	}

	public static void createTableUser(String dbName) throws SQLException {

		useDatabase(dbName);

		String sql = "CREATE TABLE IF NOT EXISTS Utente (\nid_u INT NOT NULL PRIMARY KEY, \nnome VARCHAR(255),\ncognome VARCHAR(255)\n )";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.executeUpdate();

	}

	public static void createTableBook(String dbName) throws SQLException {

		useDatabase(dbName);

		String sql = "CREATE TABLE IF NOT EXISTS Libro (\nid_l INT NOT NULL PRIMARY KEY, \ntesto VARCHAR(255),\nautore VARCHAR(255)\n )";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.executeUpdate();

	}

	public static void createTablePrestito(String dbName) throws SQLException {

		useDatabase(dbName);

		String sql = "CREATE TABLE IF NOT EXISTS Prestito (\nid INT NOT NULL PRIMARY KEY, \nid_l INT NOT NULL, \nid_u INT NOT NULL, \ninizio DATE,\nfine DATE, \nFOREIGN KEY (id_l) REFERENCES Libro(id_l), \nFOREIGN KEY (id_u) REFERENCES Utente(id_u) )";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.executeUpdate();

	}

	public static void insertUserBook(String dbName, String tableName, int id, String attr1, String attr2)
			throws SQLException {

		useDatabase(dbName);

		String sql = "INSERT INTO " + tableName + " VALUES ('" + id + "', '" + attr1 + "', '" + attr2 + "')";
		
		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.executeUpdate();

	}

	public static void getBooksBySurname(String dbName, String surname) throws SQLException {

		useDatabase(dbName);

		String sql = "SELECT l.testo FROM Prestito p \n" + "JOIN Utente u ON u.id_u = p.id_u \n"
				+ "JOIN Libro l ON l.id_l = p.id_l \n" + "WHERE u.cognome = ? ORDER BY p.inizio";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.setString(1, surname);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			System.out.println("testo: " + rs.getString(1));

		}

	}

	public static void getBestReader(String dbName) throws SQLException {

		useDatabase(dbName);

		String sql = "SELECT u.nome, COUNT(p.id_l) as count_books FROM Utente u \n"
				+ "JOIN Prestito p ON u.id_u = p.id_u \n" + "GROUP BY u.nome \n" + "LIMIT 3";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			System.out.print("nome: " + rs.getString(1));
			System.out.print("\tnum_libri_letti: " + rs.getInt(2) + "\n");

		}

	}

	public static void getBookNotReturnet(String dbName) throws SQLException {

		useDatabase(dbName);

		String sql = "SELECT DISTINCT u.nome, u.cognome, l.testo FROM Utente u \n"
				+ "JOIN Prestito p ON u.id_u = p.id_u \n" + "JOIN Libro l ON l.id_l = p.id_l \n"
				+ "WHERE ISNULL(p.fine);";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			System.out.print("nome: " + rs.getString(1));
			System.out.print("\tcognome: " + rs.getString(2));
			System.out.print("\ttesto: " + rs.getString(3) + "\n");

		}
	}

	public static void getHistory(String dbName, String name, String date1, String date2) throws SQLException {

		String sql = "SELECT l.testo, l.autore FROM Libro l\r\n" + "JOIN Prestito p ON l.id_l = p.id_l\r\n"
				+ "JOIN Utente u ON u.id_u = p.id_u\r\n" + "WHERE u.cognome = ? AND p.inizio BETWEEN ?  AND ? ";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ps.setString(1, name);
		ps.setString(2, date1);
		ps.setString(3, date2);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			System.out.print("testo: " + rs.getString(1));
			System.out.print("\tautore: " + rs.getString(2) + "\n");

		}

	}

	public static void getBorrowedBooks(String dbName) throws SQLException {

		String sql = "SELECT l.testo, l.autore, u.nome, u.cognome FROM Prestito p \n"
				+ "JOIN Libro l ON p.id_l = l.id_l \n" + "JOIN Utente u ON p.id_u = u.id_u \n"
				+ "WHERE DATEDIFF(p.fine, p.inizio) >= 15";

		PreparedStatement ps = startConnection(dbName).prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

			System.out.print("testo: " + rs.getString(1));
			System.out.print("\tautore: " + rs.getString(2));
			System.out.print("\tnome: " + rs.getString(3));
			System.out.print("\tcognome: " + rs.getString(4) + "\n");

		}

	}

}
