export function NotFound(){
    return (
        <>
            <h1>Not found</h1>
        </>
    );
}